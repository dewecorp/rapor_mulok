-- Backup Database Rapor Mulok Khusus
-- Tanggal: 2025-12-27 09:08:39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

DROP TABLE IF EXISTS `backup`;
CREATE TABLE `backup` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama_backup` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `ukuran_file` bigint DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `backup` VALUES
('1','backup_2025-12-27_09-08-33.sql','../backups/backup_2025-12-27_09-08-33.sql','7976','2025-12-27 16:08:33'),
('2','backup_2025-12-27_09-08-35.sql','../backups/backup_2025-12-27_09-08-35.sql','8135','2025-12-27 16:08:35'),
('3','backup_2025-12-27_09-08-37.sql','../backups/backup_2025-12-27_09-08-37.sql','8248','2025-12-27 16:08:37');

DROP TABLE IF EXISTS `kelas`;
CREATE TABLE `kelas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama_kelas` varchar(50) NOT NULL,
  `jumlah_siswa` int DEFAULT '0',
  `wali_kelas_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `wali_kelas_id` (`wali_kelas_id`),
  CONSTRAINT `kelas_ibfk_1` FOREIGN KEY (`wali_kelas_id`) REFERENCES `pengguna` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `materi_mulok`;
CREATE TABLE `materi_mulok` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kode_mulok` varchar(20) NOT NULL,
  `nama_mulok` varchar(100) NOT NULL,
  `jumlah_jam` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `kode_mulok` (`kode_mulok`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `materi_mulok` VALUES
('1','HAFAH','Hafalan Asmaul Husna','1','2025-12-27 12:54:56','2025-12-27 12:54:56');

DROP TABLE IF EXISTS `mengampu_materi`;
CREATE TABLE `mengampu_materi` (
  `id` int NOT NULL AUTO_INCREMENT,
  `materi_mulok_id` int NOT NULL,
  `guru_id` int NOT NULL,
  `kelas_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_mengampu` (`materi_mulok_id`,`guru_id`,`kelas_id`),
  KEY `guru_id` (`guru_id`),
  KEY `kelas_id` (`kelas_id`),
  CONSTRAINT `mengampu_materi_ibfk_1` FOREIGN KEY (`materi_mulok_id`) REFERENCES `materi_mulok` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mengampu_materi_ibfk_2` FOREIGN KEY (`guru_id`) REFERENCES `pengguna` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mengampu_materi_ibfk_3` FOREIGN KEY (`kelas_id`) REFERENCES `kelas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `nilai_kkm`;
CREATE TABLE `nilai_kkm` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kelas_id` int NOT NULL,
  `kkm` int DEFAULT '70',
  `predikat_a_min` int DEFAULT '90',
  `predikat_a_max` int DEFAULT '100',
  `predikat_b_min` int DEFAULT '80',
  `predikat_b_max` int DEFAULT '89',
  `predikat_c_min` int DEFAULT '70',
  `predikat_c_max` int DEFAULT '79',
  `predikat_d_min` int DEFAULT '0',
  `predikat_d_max` int DEFAULT '69',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_kkm_kelas` (`kelas_id`),
  CONSTRAINT `nilai_kkm_ibfk_1` FOREIGN KEY (`kelas_id`) REFERENCES `kelas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `nilai_siswa`;
CREATE TABLE `nilai_siswa` (
  `id` int NOT NULL AUTO_INCREMENT,
  `siswa_id` int NOT NULL,
  `materi_mulok_id` int NOT NULL,
  `kelas_id` int NOT NULL,
  `guru_id` int NOT NULL,
  `nilai_pengetahuan` int DEFAULT NULL,
  `nilai_keterampilan` int DEFAULT NULL,
  `nilai_sikap` varchar(20) DEFAULT NULL,
  `semester` enum('1','2') DEFAULT '1',
  `tahun_ajaran` varchar(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_nilai` (`siswa_id`,`materi_mulok_id`,`semester`,`tahun_ajaran`),
  KEY `materi_mulok_id` (`materi_mulok_id`),
  KEY `kelas_id` (`kelas_id`),
  KEY `guru_id` (`guru_id`),
  CONSTRAINT `nilai_siswa_ibfk_1` FOREIGN KEY (`siswa_id`) REFERENCES `siswa` (`id`) ON DELETE CASCADE,
  CONSTRAINT `nilai_siswa_ibfk_2` FOREIGN KEY (`materi_mulok_id`) REFERENCES `materi_mulok` (`id`) ON DELETE CASCADE,
  CONSTRAINT `nilai_siswa_ibfk_3` FOREIGN KEY (`kelas_id`) REFERENCES `kelas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `nilai_siswa_ibfk_4` FOREIGN KEY (`guru_id`) REFERENCES `pengguna` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `pengaturan_cetak`;
CREATE TABLE `pengaturan_cetak` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tempat_cetak` varchar(200) DEFAULT NULL,
  `tanggal_cetak` date DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `pengaturan_cetak` VALUES
('1','','2025-12-27','2025-12-27 16:06:52');

DROP TABLE IF EXISTS `pengguna`;
CREATE TABLE `pengguna` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `jenis_kelamin` enum('L','P') DEFAULT 'L',
  `tempat_lahir` varchar(50) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `foto` varchar(255) DEFAULT 'default.png',
  `role` enum('proktor','wali_kelas','guru') DEFAULT 'guru',
  `is_proktor_utama` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `pengguna` VALUES
('1','Administrator',NULL,'L',NULL,NULL,'admin','$2y$10$2gCnc1bpZjx9oeUAHI3S/.w0/CripKQiiaaecMeIOYRo0mD47bfOi','default.png','proktor','1','2025-12-27 10:41:57','2025-12-27 11:35:06');

DROP TABLE IF EXISTS `profil_madrasah`;
CREATE TABLE `profil_madrasah` (
  `id` int NOT NULL AUTO_INCREMENT,
  `logo` varchar(255) DEFAULT 'logo.png',
  `nama_madrasah` varchar(200) NOT NULL,
  `nsm` varchar(50) DEFAULT NULL,
  `npsn` varchar(50) DEFAULT NULL,
  `alamat` text,
  `kecamatan` varchar(100) DEFAULT NULL,
  `kabupaten` varchar(100) DEFAULT NULL,
  `provinsi` varchar(100) DEFAULT NULL,
  `nama_kepala` varchar(100) DEFAULT NULL,
  `nip_kepala` varchar(50) DEFAULT NULL,
  `tahun_ajaran_aktif` varchar(20) DEFAULT NULL,
  `semester_aktif` enum('1','2') DEFAULT '1',
  `foto_login` varchar(255) DEFAULT 'login-bg.jpg',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `profil_madrasah` VALUES
('1','logo_1766810294.png','MI Sultan Fattah Sukosono','','','','','','','','','2024/2025','1','login_1766813165.jpg','2025-12-27 12:26:05'),
('2','logo.png','MI Sultan Fattah Sukosono','','','','','','',NULL,NULL,'2024/2025','1','login-bg.jpg','2025-12-27 10:57:11');

DROP TABLE IF EXISTS `siswa`;
CREATE TABLE `siswa` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nisn` varchar(20) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jenis_kelamin` enum('L','P') DEFAULT 'L',
  `tempat_lahir` varchar(50) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `kelas_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nisn` (`nisn`),
  KEY `kelas_id` (`kelas_id`),
  CONSTRAINT `siswa_ibfk_1` FOREIGN KEY (`kelas_id`) REFERENCES `kelas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

COMMIT;
